# 🛒 Retail Sales Data Analysis Report

**Dataset**: Superstore Sales (Kaggle)  
**Duration**: January 2014 – December 2017  
**Tools Used**: Python, Pandas, Matplotlib, Seaborn, Jupyter Notebook

---

## 🔍 Objectives

- Understand sales distribution across categories and regions
- Analyze profitability and margins by state
- Identify underperforming segments and discount impact

---

## 📊 Key Insights

| Area              | Insight |
|-------------------|---------|
| **Top Region**    | West – consistently high in both sales and profit |
| **Top State**     | California – highest total sales and strong margins |
| **Low Margin**    | Texas and Illinois – high sales but low or negative profit |
| **Weak Category** | Furniture – often shows low or negative profit margins |
| **Trend**         | Positive but weak correlation between Sales and Profit |
| **Discount Impact** | Higher discounts beyond 20–30% significantly lower profit |

---

## 📈 Visualizations

- Bar plots (Sales by Region, Top/Bottom States)
- Line charts (Monthly Sales and Profit trends)
- Scatter plot with regression line (Sales vs Profit)
- Heatmaps (Profit by Category/Sub-Category)
- Trend lines per Category (Furniture, Tech, Office Supplies)

---

## ✅ Recommendations

- Re-evaluate discounting strategies in Furniture category.
- Target states with high sales but poor profit for cost optimization.
- Expand Technology category in high-performing states.
- Investigate causes of loss-making transactions with high sales.